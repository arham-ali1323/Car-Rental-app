import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.min.css";
import CarNavbar from "./Components/Navbar";
import Footer from "./Components/Footer";
import Home from "./pages/Home";
import Cars from "./pages/Cars";
import MyBooking from "./pages/Mybooking";
// import Contact from './pages/Contact';

function App() {
  return (
    <Router>
      <CarNavbar />

      <Routes>
  <Route path="/" element={<Home />} />
  <Route path="/cars" element={<Cars />} />
  <Route path="/my-booking" element={<MyBooking />} />
        {/*     <Route path="/contact" element={<Contact />} /> */}
      </Routes>

      <Footer />
    </Router>
  );
}

export default App;
