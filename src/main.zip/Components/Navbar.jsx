import Container from "react-bootstrap/Container";
import { NavLink } from "react-router-dom";
import Nav from "react-bootstrap/Nav";
import Navbar from "react-bootstrap/Navbar";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Logo from "../assets/image/logo.svg";

function CarNavbar() {
  return (
    <Navbar collapseOnSelect expand="lg" bg="light" variant="light">
      <Container>
        <Navbar.Brand as={NavLink} to="/">
          <img src={Logo} alt="logo" height="40" />
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="ms-auto align-items-center">
            <NavLink
              to="/"
              className={({ isActive }) =>
                "nav-link" + (isActive ? " active text-primary fw-bold" : "")
              }
            >
              Home
            </NavLink>

            <NavLink
              to="/cars"
              className={({ isActive }) =>
                "nav-link" + (isActive ? " active text-primary fw-bold" : "")
              }
            >
              Cars
            </NavLink>

            <NavLink
              to="/my-booking"
              className={({ isActive }) =>
                "nav-link" + (isActive ? " active text-primary fw-bold" : "")
              }
            >
              My Booking
            </NavLink>
            {/* <NavLink to="/my-booking" className="nav-link">My Booking</NavLink> */}

            <Form className="d-flex ms-3">
              <Row className="g-2 align-items-center">
                <Col xs="auto">
                  <Form.Control
                    type="text"
                    placeholder="Search"
                    className="me-sm-2"
                  />
                </Col>
                <Col xs="auto">
                  <Button variant="link" className="text-decoration-none">
                    List Cars
                  </Button>
                  <Button variant="primary">Login</Button>
                </Col>
              </Row>
            </Form>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default CarNavbar;
